import os
import pandas as pd

from sklearn.preprocessing import StandardScaler
import xgboost as xgb

from utils import train_xgb, y_columns, get_x_y_labels, train_svm
# from src.deep_nir.VRAI.utils import get_data, compute_regression_metrics

out_path = "/mnt/c/Users/aless/Desktop/ricerca/deep-nir/src/deep_nir/VRAI"
in_path = "/mnt/c/Users/aless/Desktop/ricerca/deep-nir/data/raw/Grain"

def main(dataset, path, model_type="xgb", scale=False):
    # Load training and validation data from Excel sheets
    for sheet_name in sheet_names:
        if sheet_name == "DATASET":
            data = pd.read_excel(path, sheet_name=sheet_name)
            val_data = pd.read_excel(path, sheet_name="VALID")
            val_data.columns = val_data.columns.map(str)
        else:
            data = pd.read_excel(path, sheet_name=sheet_name, header=1)
            val_data = None
        print(f"Training model for sheet: {sheet_name}")
        data.columns = data.columns.map(str)
        
        # Save everything related to this training to a csv file
        output_csv = os.path.join(out_path, "outputs", f"{dataset}_{sheet_name}")

        # Get dtrain and dtest 
        train_data = data
        if val_data is None:
            train_data = data.sample(frac=0.7, random_state=42)
            val_data = data.drop(train_data.index)
            
        # Train a different model for each target
        for col_idx, y_col in enumerate(y_columns[sheet_name]):
            print("\nTraining for target:", y_col)
            
            # Training set
            X_train, y_train = get_x_y_labels(train_data, y_col)

            # Validation set
            X_val, y_val = get_x_y_labels(val_data, y_col if sheet_name != "DATASET" else y_columns["VALID"][col_idx])
            
            # remove all rows with 0 in y_train
            mask = y_train != 0
            X_train = X_train[mask]
            y_train = y_train[mask]

            # Normalize data. X_train is a dataframe, while y_train is a series
            if scale:
                scaler_X = StandardScaler()
                X_train = pd.DataFrame(scaler_X.fit_transform(X_train), columns=X_train.columns)
                X_val = pd.DataFrame(scaler_X.transform(X_val), columns=X_val.columns)
                
                scaler_y = StandardScaler()
                y_train = pd.Series(scaler_y.fit_transform(y_train.values.reshape(-1, 1)).flatten(), index=y_train.index)
                y_val = pd.Series(scaler_y.transform(y_val.values.reshape(-1, 1)).flatten(), index=y_val.index)
        
            # Prepare DMatrix for XGBoost
            dtrain = xgb.DMatrix(X_train, label=y_train)
            dtest = xgb.DMatrix(X_val, label=y_val)
        
            if model_type == "xgb":
                train_xgb(dtrain, dtest, y_val, y_col, output_csv, scale=scale)
            elif model_type == "svm":
                train_svm(X_train, X_val, y_train, y_val, y_col, output_csv, scale=scale)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Train models on NIR data.")
    parser.add_argument("--model", type=str, choices=["xgb", "svm"], default="xgb", help="Type of model to train.")
    parser.add_argument("--scale", action="store_true", help="Whether to scale the data.")
    
    args = parser.parse_args()
    
    sheet_names = ["DATASET"]#, "ALL_FOSS", "ALL_Gonzaga", "ALL_LUFA"]
    # sheet_names = ["ALL_FOSS", "ALL_Gonzaga", "ALL_LUFA"]

    for dir in os.listdir(in_path):
        if dir == "08_CornGrain":
            for file in os.listdir(os.path.join(in_path, dir)):
                if file.endswith("DATASET.xlsx"):
                    print(f"Processing dataset: {dir}, file: {file}")
                    main(dir, path=os.path.join(in_path, dir, file), model_type=args.model, scale=args.scale)