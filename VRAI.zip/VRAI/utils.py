import numpy as np
import pandas as pd
import xgboost as xgb

from sklearn.svm import SVR
from sklearn.metrics import r2_score
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV, KFold

# Define target columns for the dataset in Grain > 08_CornGrain 
y_columns = {
    "DATASET": ["DM", "Starch", "Protein", "ADF", "NDF", "Ash", "Crude Fat", "Crude Fib."],
    "VALID": ["DM", "Starch", "Crude Protein", "ADF", "NDF", "Ash", "Crude Fat", "Crude Fiber"],
    "ALL_FOSS": ["SS", "AMIDO_SS", "PG_SS", "ADF_SS", "NDF_SS", "CEN_SS", "EE_SS", "FG_SS"],
    "ALL_Gonzaga": ["SS", "AMIDO_SS", "PG_SS", "ADF_SS", "NDF_SS", "CEN_SS", "EE_SS", "FG_SS"],
    "ALL_LUFA": ["SS", "AMIDO_SS", "PG_SS", "ADF_SS", "NDF_SS", "CEN_SS", "EE_SS", "FG_SS"]
}

# Select features and targets
def get_x_y_labels(data, y_column):
    # debug print data columns
    # print("Data columns:", data.columns.tolist())
    # for x, find column "1100" and "1800" and get all column names between them
    y = data[y_column]
    
    # "1100" and "1800" are numbers in the dataframe columns, so we need to convert them to strings
    x_columns = data.loc[:, "1100":"1800"].columns.tolist()
    X = data[x_columns]
    
    return X, y

# Compute regression metrics
def compute_regression_metrics(y_true, y_pred):
    n = len(y_true)
    residuals = y_true - y_pred
    bias = residuals.mean()
    sep = (residuals ** 2).sum() / (n - 1)
    sepc = ((residuals - bias) ** 2).sum() / (n - 1)
    r2 = r2_score(y_true, y_pred)
    slope = np.corrcoef(y_true, y_pred)[0, 1] * (y_pred.std() / y_true.std())

    # Add MIN, MAX, AVG, STD for y_true and y_pred
    min_true = np.min(y_true)
    max_true = np.max(y_true)
    avg_true = np.mean(y_true)
    std_true = np.std(y_true)
    min_pred = np.min(y_pred)
    max_pred = np.max(y_pred)
    avg_pred = np.mean(y_pred)
    std_pred = np.std(y_pred)
    
    return {
        "SEP": sep, "Bias": bias, "SEPC": sepc, "R2": r2, "Slope": slope, "N": n,
        "Min_True": min_true, "Max_True": max_true, "Avg_True": avg_true, "Std_True": std_true,
        "Min_Pred": min_pred, "Max_Pred": max_pred, "Avg_Pred": avg_pred, "Std_Pred": std_pred}


def train_xgb(dtrain, dtest, y_val, y_col, output_csv, scale=False):
    train_dict = {}

    # Set parameters for XGBoost. very few samples, so we need a simple model
    params = {
        "objective": "reg:squarederror",
        "max_depth": 2,
        "eta": 0.01,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "eval_metric": "rmse"
    }
    num_rounds = 100

    # Train the model: show evaluation metrics on validation set along with SEP, Bias, SEPC, R2, Slope, N (at the end)
    evals = [(dtrain, 'train'), (dtest, 'eval')]
    model = xgb.train(params, dtrain, num_boost_round=num_rounds, evals=evals)
    
    # Make predictions: print rmse on validation set
    preds = model.predict(dtest)
    # y_val may not have ".values" if it's a single column
    y_val_array = y_val.values.ravel() if hasattr(y_val, 'values') else y_val.ravel()
    rmse = ((preds - y_val_array) ** 2).mean() ** 0.5
    print(f"Validation RMSE: {rmse}")
    metrics = compute_regression_metrics(y_val_array, preds)
    for key, value in metrics.items():
        train_dict["performance_" + key + "_" + y_col] = value

    # Make predictions on training set
    train_preds = model.predict(dtrain)
    train_rmse = ((train_preds - dtrain.get_label()) ** 2).mean
    print(f"Training RMSE: {train_rmse}")
    train_metrics = compute_regression_metrics(dtrain.get_label(), train_preds)
    for key, value in train_metrics.items():
        train_dict["train_" + key + "_" + y_col] = value

    # Save train_dict to csv
    df_output = pd.DataFrame([train_dict])
    with open(f"{output_csv}_{y_col}_XGB{'_scaled' if scale else ''}.csv", 'w') as f:
        df_output.to_csv(f, index=False)


def train_svm(X_train, X_val, y_train, y_val, y_col, output_csv, scale=False):
    train_dict = {}
    
    pipe = make_pipeline(
        StandardScaler(),
        SVR(kernel="rbf")
    )

    param_grid = {
        "svr__C": [0.1, 1, 10, 100],
        "svr__epsilon": [0.01, 0.1, 1.0],
        "svr__gamma": ["scale", 0.1, 0.01, 0.001]
    }

    cv = KFold(n_splits=5, shuffle=True, random_state=42)
    reg = GridSearchCV(pipe, param_grid, cv=cv, n_jobs=-1, scoring="neg_mean_absolute_error")
    reg.fit(X_train, y_train.values.ravel())

    print("Best params:", reg.best_params_)
    pred = reg.predict(X_val)
    print("MAE:", mean_absolute_error(y_val, pred), "R2:", r2_score(y_val, pred))

    # Optional final refit on all data:
    final_reg = GridSearchCV(pipe, param_grid, cv=cv, n_jobs=-1, scoring="neg_mean_absolute_error")
    final_reg.fit(pd.concat([X_train, X_val]), pd.concat([y_train, y_val]).values.ravel())

    # Make predictions: print rmse on validation set
    preds = final_reg.predict(X_val)

    y_val_array = y_val.values.ravel() if hasattr(y_val, 'values') else y_val.ravel()
    rmse = ((preds - y_val_array) ** 2).mean() ** 0.5
    print(f"Validation RMSE: {rmse}")
    metrics = compute_regression_metrics(y_val_array, preds)
    for key, value in metrics.items():
        train_dict["val_" + key + "_" + y_col] = value

    # Make predictions on training set
    train_preds = final_reg.predict(X_train)
    train_rmse = ((train_preds - y_train.values.ravel()) ** 2).mean() ** 0.5
    print(f"Training RMSE: {train_rmse}")
    train_metrics = compute_regression_metrics(y_train.values.ravel(), train_preds)
    for key, value in train_metrics.items():
        train_dict["train_" + key + "_" + y_col] = value

    # Save train_dict to csv
    df_output = pd.DataFrame([train_dict])
    with open(f"{output_csv}_{y_col}_SVM{'_scaled' if scale else ''}.csv", 'w') as f:
        df_output.to_csv(f, index=False)
